from playwright.sync_api import Page

class LoginPage:
    def __init__(self, page: Page):
        self.page = page
        self.email = page.locator("#email")
        self.senha = page.locator("#senha")
        self.botao_entrar = page.get_by_role("button", name="Entrar")

    def acessar(self):
        self.page.goto("https://www.exemplo.com/login")

    def preencher_email(self, email):
        self.email.fill(email)

    def preencher_senha(self, senha):
        self.senha.fill(senha)

    def clicar_entrar(self):
        self.botao_entrar.click()
