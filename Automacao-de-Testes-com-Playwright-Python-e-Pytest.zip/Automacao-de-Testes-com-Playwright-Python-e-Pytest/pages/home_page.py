from playwright.sync_api import Page

class HomePage:
    def __init__(self, page: Page):
        self.page = page

    def titulo(self):
        return self.page.title()
