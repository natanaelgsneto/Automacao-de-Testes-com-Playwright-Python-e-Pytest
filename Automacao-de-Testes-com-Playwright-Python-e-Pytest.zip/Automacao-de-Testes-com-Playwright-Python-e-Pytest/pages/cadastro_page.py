from playwright.sync_api import Page

class CadastroPage:
    def __init__(self, page: Page):
        self.page = page

    def acessar(self):
        self.page.goto("https://www.exemplo.com/cadastro")
