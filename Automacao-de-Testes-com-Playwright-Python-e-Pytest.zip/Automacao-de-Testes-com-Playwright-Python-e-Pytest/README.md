# Automação de Testes com Playwright, Python e Pytest

Projeto exemplo usando Page Object Model (POM).

## Estrutura

- `pages/`: Page Objects e locators.
- `tests/`: cenários e assertions.
- `conftest.py`: fixtures/configurações do Pytest.
- `pyproject.toml`: configuração do Pytest.

## Instalação

```bash
pip install pytest pytest-playwright
python -m playwright install
```

## Executar

```bash
pytest
```

## Conceito

TESTE -> PAGE OBJECT -> PLAYWRIGHT -> NAVEGADOR -> SITE

`Page` é o tipo/classe do Playwright.
`page` é o objeto recebido pela fixture do pytest-playwright.
