# A fixture "page" é fornecida pelo pytest-playwright.
