from pages.cadastro_page import CadastroPage

def test_acessar_cadastro(page):
    cadastro = CadastroPage(page)
    cadastro.acessar()
