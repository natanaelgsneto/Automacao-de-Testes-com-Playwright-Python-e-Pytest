from pages.login_page import LoginPage

def test_login(page):
    login = LoginPage(page)
    login.acessar()
    login.preencher_email("teste@email.com")
    login.preencher_senha("123456")
    login.clicar_entrar()
